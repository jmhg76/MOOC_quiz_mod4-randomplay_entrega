const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const { models } = require("../models");

const paginate = require('../helpers/paginate').paginate;

// Autoload el quiz asociado a :quizId
exports.load = async(req, res, next, quizId) => {

    try {
        const quiz = await models.Quiz.findByPk(quizId);
        if (quiz) {
            req.load = {...req.load, quiz };
            next();
        } else {
            throw new Error('There is no quiz with id=' + quizId);
        }
    } catch (error) {
        next(error);
    }
};


// GET /quizzes
exports.index = async(req, res, next) => {

    let countOptions = {};
    let findOptions = {};

    // Search:
    const search = req.query.search || '';
    if (search) {
        const search_like = "%" + search.replace(/ +/g, "%") + "%";

        countOptions.where = {
            question: {
                [Op.like]: search_like
            }
        };
        findOptions.where = {
            question: {
                [Op.like]: search_like
            }
        };
    }

    try {
        const count = await models.Quiz.count(countOptions);

        // Pagination:

        const items_per_page = 10;

        // The page to show is given in the query
        const pageno = parseInt(req.query.pageno) || 1;

        // Create a String with the HTMl used to render the pagination buttons.
        // This String is added to a local variable of res, which is used into the application layout file.
        res.locals.paginate_control = paginate(count, items_per_page, pageno, req.url);

        findOptions.offset = items_per_page * (pageno - 1);
        findOptions.limit = items_per_page;

        const quizzes = await models.Quiz.findAll(findOptions);
        res.render('quizzes/index.ejs', {
            quizzes,
            search
        });
    } catch (error) {
        next(error);
    }
};


// GET /quizzes/:quizId
exports.show = (req, res, next) => {

    const { quiz } = req.load;

    res.render('quizzes/show', { quiz });
};


// GET /quizzes/new
exports.new = (req, res, next) => {

    const quiz = {
        question: "",
        answer: ""
    };

    res.render('quizzes/new', { quiz });
};

// POST /quizzes/create
exports.create = async(req, res, next) => {

    const { question, answer } = req.body;

    let quiz = models.Quiz.build({
        question,
        answer
    });

    try {
        // Saves only the fields question and answer into the DDBB
        quiz = await quiz.save({ fields: ["question", "answer"] });
        req.flash('success', 'Quiz created successfully.');
        res.redirect('/quizzes/' + quiz.id);
    } catch (error) {
        if (error instanceof Sequelize.ValidationError) {
            req.flash('error', 'There are errors in the form:');
            error.errors.forEach(({ message }) => req.flash('error', message));
            res.render('quizzes/new', { quiz });
        } else {
            req.flash('error', 'Error creating a new Quiz: ' + error.message);
            next(error);
        }
    }
};


// GET /quizzes/:quizId/edit
exports.edit = (req, res, next) => {

    const { quiz } = req.load;

    res.render('quizzes/edit', { quiz });
};


// PUT /quizzes/:quizId
exports.update = async(req, res, next) => {

    const { body } = req;
    const { quiz } = req.load;

    quiz.question = body.question;
    quiz.answer = body.answer;

    try {
        await quiz.save({ fields: ["question", "answer"] });
        req.flash('success', 'Quiz edited successfully.');
        res.redirect('/quizzes/' + quiz.id);
    } catch (error) {
        if (error instanceof Sequelize.ValidationError) {
            req.flash('error', 'There are errors in the form:');
            error.errors.forEach(({ message }) => req.flash('error', message));
            res.render('quizzes/edit', { quiz });
        } else {
            req.flash('error', 'Error editing the Quiz: ' + error.message);
            next(error);
        }
    }
};


// DELETE /quizzes/:quizId
exports.destroy = async(req, res, next) => {

    try {
        await req.load.quiz.destroy();
        req.flash('success', 'Quiz deleted successfully.');
        res.redirect('/goback');
    } catch (error) {
        req.flash('error', 'Error deleting the Quiz: ' + error.message);
        next(error);
    }
};


// GET /quizzes/:quizId/play
exports.play = (req, res, next) => {

    const { query } = req;
    const { quiz } = req.load;

    const answer = query.answer || '';

    res.render('quizzes/play', {
        quiz,
        answer
    });
};


// GET /quizzes/:quizId/check
exports.check = (req, res, next) => {

    const { query } = req;
    const { quiz } = req.load;

    const answer = query.answer || "";
    const result = answer.toLowerCase().trim() === quiz.answer.toLowerCase().trim();

    res.render('quizzes/result', {
        quiz,
        result,
        answer
    });
};

// Tarea 4

// GET /quizzes/randomplay
exports.randomPlay = async(req, res, next) => {
    // TODO
    // .. 
    // req.session ... añadir una propiedad que guarde los id ya consultados 
    // ... para añadirnos al una consulta tipo NotInt en las opciones del where
    /*
        // Array que contendrá los Ids de los quizzes ya resueltos para no repetirlos
        req.session.randomPlayResolved = req.session.randomPlayResolved || []; // ... la primera estará vacío
        // Mejora opcional: Recordamos cual fue el último quiz para que al recargar salga el mismo
        req.session.randomPlayLastQuizId = req.session.randomPlayLastQuizId || 0;
    */

    // Mejor tratamos la sesiómn con un objetos del siguiente modo:
    req.session.randomPlay = req.session.randomPlay || {
        resolved: [], // Array que contendrá los Ids de los quizzes ya resueltos para no repetirlos
        // Vacío inicialmente para que sea un falsy
        lastQuizId: 0 // Mejora opcional: Recordamos cual fue el último quiz para que al recargar salga el mismo
            // 0 Inicialmente para que sea un falsy
    }

    // Quiz a recuperar o bien de la sesion o bien la BDD
    let quiz;


    if (req.session.randomPlay.lastQuizId) { // ... Antes req.session.randomPlayLastQuizId
        // ... siempre pregunto por el mismo quiz ... si recargo
        quiz = await models.Quiz.findByPk(req.session.randomPlay.lastQuizId);
    } else {

        const total = await models.Quiz.count();
        const quedan = total - req.session.randomPlay.resolved.length;

        quiz = await models.Quiz.findOne({
            where: {
                'id': {
                    [Sequelize.Op.notIn]: req.session.randomPlay.resolved
                }
            },
            offset: Math.floor(Math.random() * quedan)
        });
    }
    // Todos los quizzes acertados son los que están en éste Array 
    const score = req.session.randomPlay.resolved.length;

    if (quiz) { // Si se devuelve algún quiz pendiente de contestar ...
        req.session.randomPlay.lastQuizId = quiz.id; // ... lo guardamos para sabre que nos preguntaron
        // ... render a la vista de jugar aleatorio, pasando el quiz a preguntar y el score "la puntuación" actual, que es lo que necesita la vista
        res.render('quizzes/random_play', { quiz, score });
    } else { // Si NO hay más quiz ...
        delete req.session.randomPlay; // ... borro la variable de sesión que guarda lo que acerté ...
        res.render('quizzes/random_nomore', { score }); // ... rendierizo la vista acabé de jugar pasando el score "la puntuación" final 
    }

}

// GET /quizzes/randomplay/:quizId(\\d+)
exports.randomCheck = async(req, res, next) => {
    // Recuperamos los datos de la sesión ... aunque no debería de ocurrir el entrar
    req.session.randomPlay = req.session.randomPlay || {
        resolved: [], // Array que contendrá los Ids de los quizzes ya resueltos para no repetirlos
        // Vacío inicialmente para que sea un falsy
        lastQuizId: 0 // Mejora opcional: Recordamos cual fue el último quiz para que al recargar salga el mismo
            // 0 Inicialmente para que sea un falsy
    }

    const answer = req.query.answer || ""; // Aquí es donde está la respuesta que dio el usuario
    const { quiz } = req.load; // Aquí es donde está la respuesta correcta

    const result = answer.toLowerCase().trim() === quiz.answer.toLowerCase().trim();

    if (result) { // ... Hemos acertado ...
        // req.session.randomPlay.lastQuizId lo podemos borrar para que nos pregunten uno nuevo
        req.session.randomPlay.lastQuizId = 0;

        // Añadimos al req.session.randomPlay.resolved el Id del Quiz que hemos acertado
        if (req.session.randomPlay.resolved.includes(quiz.id) === false) { // Sin repetir los Ids
            req.session.randomPlay.resolved.push(quiz.id);
        }

        // Todos los quizzes acertados son los que están en éste Array 
        const score = req.session.randomPlay.resolved.length;

        // Renderizamos la vista de que hemos acertado, la respuesta que dimos y con la nueva puntuación
        res.render('quizzes/random_result', { result, answer, score });
    } else { // ... NO hemos acertado ... 
        // Todos los quizzes acertados son los que están en éste Array 
        const score = req.session.randomPlay.resolved.length;
        // Destruir la propiedad req.session.randomPlayResolved para volver al estado inicial,
        delete req.session.randomPlay;
        // y renderizar la vista quizzes/random_result.ejs con los parámetros adecuados.
        res.render('quizzes/random_result', { result, answer, score });
    }

}